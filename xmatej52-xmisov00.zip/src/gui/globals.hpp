/*
 * Author: Misova Miroslava
 * login:  xmisov00
 * school: VUT FIT
 * date:   22. 4. 2017
 */

#ifndef GLOBALS_HPP
#define GLOBALS_HPP
#include "g_card.hpp"
enum Stacks{ ErrStack = 0, Hidden, Visible, Single_Color, Working };
#endif // GLOBALS_HPP
